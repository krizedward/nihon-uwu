export type PositionOptionsType = 'auto' | 'top' | 'bottom';
