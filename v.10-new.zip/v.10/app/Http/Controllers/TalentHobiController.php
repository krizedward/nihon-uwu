<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TalentHobiController extends Controller
{
    //
}
