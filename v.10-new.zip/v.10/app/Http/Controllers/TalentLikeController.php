<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TalentLikeController extends Controller
{
    //
}
