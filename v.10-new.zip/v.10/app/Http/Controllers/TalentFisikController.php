<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TalentFisikController extends Controller
{
    //
}
